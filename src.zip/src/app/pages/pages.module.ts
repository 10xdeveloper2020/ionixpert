import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProductsComponent } from './products/products.component';
import { PagesComponent } from './pages.component';
import { AboutComponent } from './about/about.component';
import { RouterModule } from '@angular/router';
import { MyMaterialModule } from '../my-material/my-material.module';



@NgModule({
  declarations: [DashboardComponent, ProductsComponent, PagesComponent, AboutComponent],
  imports: [
    CommonModule,
    RouterModule,
    MyMaterialModule
  ]
})
export class PagesModule { }
